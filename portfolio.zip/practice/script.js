
//console.log("Hii");


/*
*
*multiline comment
*
*/